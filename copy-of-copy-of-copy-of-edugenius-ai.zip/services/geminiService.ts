
import { GoogleGenAI } from "@google/genai";
import { 
  ToolType, 
  LessonPlanInputs, 
  StudyGuideInputs, 
  ExamPrepInputs, 
  ConceptExplainerInputs,
  ExtendedLearningPlanInputs,
  GenerationResult
} from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const TEXT_MODEL_ID = 'gemini-2.5-flash';
const IMAGE_MODEL_ID = 'gemini-2.5-flash-image';

export const generateContent = async (
  tool: ToolType, 
  inputs: LessonPlanInputs | StudyGuideInputs | ExamPrepInputs | ConceptExplainerInputs | ExtendedLearningPlanInputs
): Promise<GenerationResult> => {
  if (!apiKey) {
    throw new Error("API Key is missing. Please set the API_KEY environment variable.");
  }

  let textPrompt = "";
  let imagePrompt = "";
  const visualInstruction = "Include ASCII art diagrams or charts in code blocks where helpful to explain concepts.";

  switch (tool) {
    case ToolType.LESSON_PLAN: {
      const p = inputs as LessonPlanInputs;
      textPrompt = `
        You are an expert curriculum designer.
        Create a detailed lesson plan on the topic: ${p.topic}
        For grade level: ${p.gradeLevel}
        Duration: ${p.duration}
        Teaching style: ${p.teachingStyle}

        Include the following sections formatted in Markdown:
        1. Learning objectives
        2. Required materials
        3. Step-by-step lesson procedure
        4. Assessment (formative + summative)
        5. Differentiation strategies
        6. Extensions and homework
        
        ${visualInstruction}
      `;
      imagePrompt = `Create a high-quality, educational illustration or diagram suitable for a lesson plan about: ${p.topic}. The image should be clear, engaging, and relevant to grade level ${p.gradeLevel}.`;
      break;
    }
    case ToolType.STUDY_GUIDE: {
      const p = inputs as StudyGuideInputs;
      textPrompt = `
        Create a student-friendly study guide on: ${p.topic}
        Target student level: ${p.level}

        Include the following sections formatted in Markdown:
        - Key concepts
        - Definitions
        - Visuals: Provide detailed ASCII art diagrams or flowcharts.
        - Summary
        - Practice questions with answers
        
        ${visualInstruction}
      `;
      imagePrompt = `Create a detailed educational diagram or infographic explaining the key concepts of: ${p.topic}. It should be suitable for a study guide.`;
      break;
    }
    case ToolType.EXAM_PREP: {
      const p = inputs as ExamPrepInputs;
      textPrompt = `
        Generate exam preparation questions for: ${p.topic}
        Difficulty: ${p.difficulty}
        Format: ${p.questionTypes.join(', ')}

        Include an answer key at the end.
        Format in clear Markdown.
        
        If applicable, include an ASCII diagram as part of a question or explanation.
      `;
      imagePrompt = `Create a relevant visual aid, diagram, or illustration that could be used in an exam or study material for the topic: ${p.topic}.`;
      break;
    }
    case ToolType.CONCEPT_EXPLAINER: {
      const p = inputs as ConceptExplainerInputs;
      textPrompt = `
        Explain the concept: ${p.topic}
        
        Break the explanation into the following sections formatted in Markdown:
        - Simple explanation (EL15 style)
        - Real-world analogy
        - Step-by-step breakdown
        - Common misconceptions
        - Quick quiz (3 questions)
        
        ${visualInstruction}
      `;
      imagePrompt = `Create a simple, intuitive illustration or analogy diagram that explains the concept: ${p.topic}.`;
      break;
    }
    case ToolType.EXTENDED_LEARNING_PLAN: {
      const p = inputs as ExtendedLearningPlanInputs;
      textPrompt = `
        You are an expert academic counselor and strategic learning coach.
        Create a comprehensive Extended Learning Plan for the goal: ${p.goal}
        
        Parameters:
        - Total Duration: ${p.duration}
        - Current Skill Level: ${p.currentLevel}
        - Weekly Time Commitment: ${p.weeklyCommitment}

        Structure the plan in Markdown:
        1. **Executive Summary & Milestones**: High-level goals.
        2. **Weekly/Module Breakdown**: A structured timeline (e.g., Week 1-2, Month 1) detailing topics, specific activities, and focus areas.
        3. **Curated Resources**: Recommend specific types of books, courses, documentation, or project ideas.
        4. **Skill Assessments**: Checkpoints to verify progress.
        5. **Final Capstone Project**: A project idea to demonstrate mastery.
        
        ${visualInstruction}
      `;
      imagePrompt = `Create a visual roadmap or timeline infographic that represents a learning journey for: ${p.goal}. It should look motivating and structured.`;
      break;
    }
  }

  try {
    // Execute text generation
    const textPromise = ai.models.generateContent({
      model: TEXT_MODEL_ID,
      contents: textPrompt,
      config: {
        systemInstruction: "You are a helpful and knowledgeable educational assistant. Output nicely formatted Markdown with ASCII diagrams where requested.",
      }
    });

    // Execute image generation (allow it to fail without failing the whole request)
    const imagePromise = ai.models.generateContent({
      model: IMAGE_MODEL_ID,
      contents: { parts: [{ text: imagePrompt }] },
      config: {
        imageConfig: {
          aspectRatio: "16:9"
        }
      }
    }).catch(e => {
      console.warn("Image generation failed:", e);
      return null;
    });

    const [textResponse, imageResponse] = await Promise.all([textPromise, imagePromise]);

    let text = textResponse.text || "No content generated.";
    let imageUrl: string | undefined = undefined;

    if (imageResponse && imageResponse.candidates?.[0]?.content?.parts) {
      for (const part of imageResponse.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
          break;
        }
      }
    }

    return { text, imageUrl };

  } catch (error: any) {
    console.error("Gemini API Error:", error);
    throw new Error(error.message || "Failed to generate content.");
  }
};
