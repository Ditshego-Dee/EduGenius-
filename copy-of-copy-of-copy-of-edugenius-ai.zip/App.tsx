
import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  GraduationCap, 
  FileQuestion, 
  Lightbulb, 
  Wand2, 
  History,
  AlertCircle,
  Menu,
  Zap,
  Calendar
} from 'lucide-react';
import { generateContent } from './services/geminiService';
import { 
  ToolType, 
  GeneratorState, 
  LessonPlanInputs, 
  StudyGuideInputs, 
  ExamPrepInputs, 
  ConceptExplainerInputs,
  ExtendedLearningPlanInputs,
  HistoryItem
} from './types';
import HistorySidebar from './components/HistorySidebar';
import ResultDisplay from './components/ResultDisplay';
import PaymentModal from './components/PaymentModal';

// Default initial states for forms
const initialLessonPlan: LessonPlanInputs = { topic: '', gradeLevel: '', duration: '', teachingStyle: '' };
const initialStudyGuide: StudyGuideInputs = { topic: '', level: '' };
const initialExamPrep: ExamPrepInputs = { topic: '', difficulty: 'Medium', questionTypes: ['Multiple Choice', 'Short Answer'] };
const initialConceptExplainer: ConceptExplainerInputs = { topic: '' };
const initialExtendedPlan: ExtendedLearningPlanInputs = { goal: '', duration: '', currentLevel: 'Beginner', weeklyCommitment: '' };

const MAX_FREE_USAGE = 5;

const App: React.FC = () => {
  const [activeTool, setActiveTool] = useState<ToolType>(ToolType.LESSON_PLAN);
  const [generatorState, setGeneratorState] = useState<GeneratorState>({
    isLoading: false,
    result: null,
    error: null
  });
  
  // Usage State
  const [usageCount, setUsageCount] = useState<number>(() => {
    return parseInt(localStorage.getItem('edugenius_usage_count') || '0', 10);
  });
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  // Form State
  const [lessonPlanInputs, setLessonPlanInputs] = useState<LessonPlanInputs>(initialLessonPlan);
  const [studyGuideInputs, setStudyGuideInputs] = useState<StudyGuideInputs>(initialStudyGuide);
  const [examPrepInputs, setExamPrepInputs] = useState<ExamPrepInputs>(initialExamPrep);
  const [conceptInputs, setConceptInputs] = useState<ConceptExplainerInputs>(initialConceptExplainer);
  const [extendedPlanInputs, setExtendedPlanInputs] = useState<ExtendedLearningPlanInputs>(initialExtendedPlan);

  // History State
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const saved = localStorage.getItem('edugenius_history');
    return saved ? JSON.parse(saved) : [];
  });
  const [showHistory, setShowHistory] = useState(false);
  const [currentHistoryId, setCurrentHistoryId] = useState<string | null>(null);

  // Save history to local storage
  useEffect(() => {
    localStorage.setItem('edugenius_history', JSON.stringify(history));
  }, [history]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();

    if (usageCount >= MAX_FREE_USAGE) {
      setShowPaymentModal(true);
      return;
    }

    setGeneratorState({ isLoading: true, result: null, error: null });
    setCurrentHistoryId(null);

    try {
      let inputs: any;
      let topic = '';

      switch (activeTool) {
        case ToolType.LESSON_PLAN:
          inputs = lessonPlanInputs;
          topic = lessonPlanInputs.topic;
          break;
        case ToolType.STUDY_GUIDE:
          inputs = studyGuideInputs;
          topic = studyGuideInputs.topic;
          break;
        case ToolType.EXAM_PREP:
          inputs = examPrepInputs;
          topic = examPrepInputs.topic;
          break;
        case ToolType.CONCEPT_EXPLAINER:
          inputs = conceptInputs;
          topic = conceptInputs.topic;
          break;
        case ToolType.EXTENDED_LEARNING_PLAN:
          inputs = extendedPlanInputs;
          topic = extendedPlanInputs.goal;
          break;
      }

      if (!topic.trim()) {
        throw new Error("Please enter a topic or goal.");
      }

      const result = await generateContent(activeTool, inputs);
      
      // Increment usage count on success
      const newCount = usageCount + 1;
      setUsageCount(newCount);
      localStorage.setItem('edugenius_usage_count', newCount.toString());

      setGeneratorState({
        isLoading: false,
        result: result,
        error: null
      });

    } catch (err: any) {
      setGeneratorState({
        isLoading: false,
        result: null,
        error: err.message
      });
    }
  };

  const handleSaveToHistory = () => {
    if (generatorState.result && !currentHistoryId) {
      const topic = 
        activeTool === ToolType.LESSON_PLAN ? lessonPlanInputs.topic :
        activeTool === ToolType.STUDY_GUIDE ? studyGuideInputs.topic :
        activeTool === ToolType.EXAM_PREP ? examPrepInputs.topic :
        activeTool === ToolType.EXTENDED_LEARNING_PLAN ? extendedPlanInputs.goal :
        conceptInputs.topic;

      const newItem: HistoryItem = {
        id: Date.now().toString(),
        tool: activeTool,
        title: topic || 'Untitled',
        content: generatorState.result.text,
        imageUrl: generatorState.result.imageUrl,
        timestamp: Date.now()
      };
      setHistory([newItem, ...history]);
      setCurrentHistoryId(newItem.id);
    }
  };

  const handleHistorySelect = (item: HistoryItem) => {
    setActiveTool(item.tool);
    setGeneratorState({ 
      isLoading: false, 
      result: { text: item.content, imageUrl: item.imageUrl }, 
      error: null 
    });
    setCurrentHistoryId(item.id);
    
    // Partially restore inputs for context
    if (item.tool === ToolType.LESSON_PLAN) setLessonPlanInputs(p => ({ ...p, topic: item.title }));
    if (item.tool === ToolType.STUDY_GUIDE) setStudyGuideInputs(p => ({ ...p, topic: item.title }));
    if (item.tool === ToolType.EXAM_PREP) setExamPrepInputs(p => ({ ...p, topic: item.title }));
    if (item.tool === ToolType.CONCEPT_EXPLAINER) setConceptInputs(p => ({ ...p, topic: item.title }));
    if (item.tool === ToolType.EXTENDED_LEARNING_PLAN) setExtendedPlanInputs(p => ({ ...p, goal: item.title }));
    
    setShowHistory(false);
  };

  const deleteHistoryItem = (id: string) => {
    setHistory(history.filter(h => h.id !== id));
    if (currentHistoryId === id) {
      setCurrentHistoryId(null);
    }
  };

  const renderSidebarItem = (tool: ToolType, label: string, Icon: React.ElementType, description: string) => (
    <button
      onClick={() => { setActiveTool(tool); setGeneratorState({isLoading: false, result: null, error: null}); setCurrentHistoryId(null); }}
      className={`w-full text-left p-4 rounded-xl transition-all duration-200 flex flex-col gap-1 mb-3 group border border-transparent
        ${activeTool === tool 
          ? 'bg-purple-900/40 text-white border-purple-500/50 shadow-md shadow-purple-900/20' 
          : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'
        }`}
    >
      <div className="flex items-center gap-3">
        <div className={`p-2 rounded-lg ${activeTool === tool ? 'bg-purple-500 text-white' : 'bg-slate-800 text-slate-500 group-hover:bg-slate-700 group-hover:text-purple-400'}`}>
          <Icon className="w-5 h-5" />
        </div>
        <span className="font-semibold">{label}</span>
      </div>
      <span className={`text-xs ml-12 ${activeTool === tool ? 'text-purple-200' : 'text-slate-500'}`}>
        {description}
      </span>
    </button>
  );

  return (
    <div className="min-h-screen flex bg-slate-950 relative overflow-hidden text-slate-100">
      {/* Decorative background blobs - Darkened for gothic feel */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-purple-900 rounded-full mix-blend-multiply filter blur-3xl opacity-20 -translate-x-1/2 -translate-y-1/2 pointer-events-none"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-900 rounded-full mix-blend-multiply filter blur-3xl opacity-20 translate-x-1/2 translate-y-1/2 pointer-events-none"></div>

      <PaymentModal isOpen={showPaymentModal} onClose={() => setShowPaymentModal(false)} />

      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex flex-col w-80 bg-slate-950 border-r border-slate-800 h-screen sticky top-0 z-10">
        <div className="p-6 border-b border-slate-800">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent flex items-center gap-2">
            <Wand2 className="w-6 h-6 text-purple-400" />
            EduGenius
          </h1>
          <p className="text-xs text-slate-500 mt-1">AI Curriculum Designer</p>
        </div>
        
        <nav className="flex-1 overflow-y-auto p-4">
          <div className="mb-2 text-xs font-semibold text-slate-600 uppercase tracking-wider px-2">Tools</div>
          {renderSidebarItem(ToolType.LESSON_PLAN, "Lesson Planner", BookOpen, "Detailed structured plans")}
          {renderSidebarItem(ToolType.STUDY_GUIDE, "Study Guide", GraduationCap, "Notes & practice questions")}
          {renderSidebarItem(ToolType.EXAM_PREP, "Exam Creator", FileQuestion, "Questions with answer keys")}
          {renderSidebarItem(ToolType.EXTENDED_LEARNING_PLAN, "Extended Plan", Calendar, "Long-term learning roadmap")}
          {renderSidebarItem(ToolType.CONCEPT_EXPLAINER, "Concept Explainer", Lightbulb, "Simplifications & analogies")}
        </nav>

        <div className="p-4 border-t border-slate-800 space-y-3">
          {/* Usage Meter */}
          <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-semibold text-slate-400 flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-500 fill-current" />
                Free Plan
              </span>
              <span className="text-xs font-bold text-slate-300">{usageCount}/{MAX_FREE_USAGE}</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-500 ${usageCount >= MAX_FREE_USAGE ? 'bg-red-500' : 'bg-purple-500'}`} 
                style={{ width: `${Math.min((usageCount / MAX_FREE_USAGE) * 100, 100)}%` }}
              ></div>
            </div>
          </div>

          <button 
            onClick={() => setShowHistory(true)}
            className="flex items-center gap-3 w-full p-3 rounded-lg hover:bg-slate-900 text-slate-400 hover:text-slate-200 transition-colors"
          >
            <History className="w-5 h-5" />
            <span className="font-medium">View History</span>
          </button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-slate-950 border-b border-slate-800 z-20 px-4 flex items-center justify-between">
         <h1 className="text-lg font-bold text-purple-400 flex items-center gap-2">
            <Wand2 className="w-5 h-5" />
            EduGenius
          </h1>
          <div className="flex gap-2">
            <div className="flex items-center gap-1 px-3 py-1 bg-slate-900 rounded-full text-xs font-medium text-slate-400 border border-slate-800">
               <Zap className="w-3 h-3 text-amber-500 fill-current" />
               {usageCount}/{MAX_FREE_USAGE}
            </div>
            <button onClick={() => setShowHistory(true)} className="p-2 hover:bg-slate-900 rounded-lg">
              <History className="w-5 h-5 text-slate-400" />
            </button>
          </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden lg:static pt-16 lg:pt-0 relative">
        <div className="flex-1 overflow-y-auto p-4 lg:p-8">
          <div className="max-w-6xl mx-auto grid grid-cols-1 xl:grid-cols-12 gap-6 h-full">
            
            {/* Input Form Column */}
            <div className="xl:col-span-4 flex flex-col gap-6">
              
              {/* Mobile Tool Selection */}
              <div className="lg:hidden flex overflow-x-auto gap-2 pb-2 mb-2 no-scrollbar">
                {[
                  { id: ToolType.LESSON_PLAN, icon: BookOpen, label: 'Lesson' },
                  { id: ToolType.STUDY_GUIDE, icon: GraduationCap, label: 'Guide' },
                  { id: ToolType.EXAM_PREP, icon: FileQuestion, label: 'Exam' },
                  { id: ToolType.EXTENDED_LEARNING_PLAN, icon: Calendar, label: 'Plan' },
                  { id: ToolType.CONCEPT_EXPLAINER, icon: Lightbulb, label: 'Concept' },
                ].map(tool => (
                  <button
                    key={tool.id}
                    onClick={() => setActiveTool(tool.id as ToolType)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors
                      ${activeTool === tool.id ? 'bg-purple-600 text-white' : 'bg-slate-900 text-slate-400 border border-slate-800'}`}
                  >
                    <tool.icon className="w-4 h-4" />
                    {tool.label}
                  </button>
                ))}
              </div>

              <div className="bg-slate-900 rounded-xl shadow-lg border border-slate-800 p-6 animate-fade-in">
                <h2 className="text-xl font-bold text-slate-100 mb-6 flex items-center gap-2">
                  {activeTool === ToolType.LESSON_PLAN && <BookOpen className="w-6 h-6 text-blue-400" />}
                  {activeTool === ToolType.STUDY_GUIDE && <GraduationCap className="w-6 h-6 text-green-400" />}
                  {activeTool === ToolType.EXAM_PREP && <FileQuestion className="w-6 h-6 text-purple-400" />}
                  {activeTool === ToolType.EXTENDED_LEARNING_PLAN && <Calendar className="w-6 h-6 text-pink-400" />}
                  {activeTool === ToolType.CONCEPT_EXPLAINER && <Lightbulb className="w-6 h-6 text-amber-400" />}
                  
                  {activeTool === ToolType.LESSON_PLAN && "Create Lesson Plan"}
                  {activeTool === ToolType.STUDY_GUIDE && "Create Study Guide"}
                  {activeTool === ToolType.EXAM_PREP && "Create Exam Questions"}
                  {activeTool === ToolType.EXTENDED_LEARNING_PLAN && "Extended Learning Plan"}
                  {activeTool === ToolType.CONCEPT_EXPLAINER && "Explain Concept"}
                </h2>

                <form onSubmit={handleGenerate} className="space-y-4">
                  {/* Dynamic Inputs Based on Tool */}
                  
                  {activeTool === ToolType.LESSON_PLAN && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Topic</label>
                        <input 
                          type="text" 
                          required
                          value={lessonPlanInputs.topic}
                          onChange={e => setLessonPlanInputs({...lessonPlanInputs, topic: e.target.value})}
                          placeholder="e.g. Photosynthesis, The Cold War"
                          className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all placeholder-slate-500"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-slate-400 mb-1">Grade Level</label>
                          <input 
                            type="text"
                            required 
                            value={lessonPlanInputs.gradeLevel}
                            onChange={e => setLessonPlanInputs({...lessonPlanInputs, gradeLevel: e.target.value})}
                            placeholder="e.g. 5th Grade"
                            className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all placeholder-slate-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-slate-400 mb-1">Duration</label>
                          <input 
                            type="text"
                            required 
                            value={lessonPlanInputs.duration}
                            onChange={e => setLessonPlanInputs({...lessonPlanInputs, duration: e.target.value})}
                            placeholder="e.g. 60 mins"
                            className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all placeholder-slate-500"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Teaching Style</label>
                        <select 
                          value={lessonPlanInputs.teachingStyle}
                          onChange={e => setLessonPlanInputs({...lessonPlanInputs, teachingStyle: e.target.value})}
                          className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all"
                        >
                          <option value="">Select Style</option>
                          <option value="Direct Instruction">Direct Instruction</option>
                          <option value="Inquiry-Based">Inquiry-Based</option>
                          <option value="Project-Based">Project-Based</option>
                          <option value="Gamified">Gamified</option>
                          <option value="Collaborative">Collaborative</option>
                        </select>
                      </div>
                    </>
                  )}

                  {activeTool === ToolType.STUDY_GUIDE && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Topic</label>
                        <input 
                          type="text" 
                          required
                          value={studyGuideInputs.topic}
                          onChange={e => setStudyGuideInputs({...studyGuideInputs, topic: e.target.value})}
                          placeholder="e.g. Cell Biology"
                          className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all placeholder-slate-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Student Level</label>
                        <select 
                          value={studyGuideInputs.level}
                          onChange={e => setStudyGuideInputs({...studyGuideInputs, level: e.target.value})}
                          className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all"
                        >
                          <option value="">Select Level</option>
                          <option value="Elementary">Elementary</option>
                          <option value="Middle School">Middle School</option>
                          <option value="High School">High School</option>
                          <option value="Undergraduate">Undergraduate</option>
                          <option value="Graduate">Graduate</option>
                        </select>
                      </div>
                    </>
                  )}

                  {activeTool === ToolType.EXAM_PREP && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Topic</label>
                        <input 
                          type="text"
                          required 
                          value={examPrepInputs.topic}
                          onChange={e => setExamPrepInputs({...examPrepInputs, topic: e.target.value})}
                          placeholder="e.g. World War II"
                          className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all placeholder-slate-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Difficulty</label>
                        <div className="flex gap-2">
                          {['Easy', 'Medium', 'Hard'].map(d => (
                            <button
                              key={d}
                              type="button"
                              onClick={() => setExamPrepInputs({...examPrepInputs, difficulty: d})}
                              className={`flex-1 py-2 text-sm rounded-lg border transition-all ${examPrepInputs.difficulty === d ? 'bg-purple-900/50 border-purple-500 text-purple-300 font-medium' : 'border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-400'}`}
                            >
                              {d}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Question Format</label>
                        <div className="space-y-2">
                          {['Multiple Choice', 'Short Answer', 'Long Response', 'True/False'].map(type => (
                            <label key={type} className="flex items-center gap-2 cursor-pointer">
                              <input 
                                type="checkbox"
                                checked={examPrepInputs.questionTypes.includes(type)}
                                onChange={e => {
                                  const newTypes = e.target.checked 
                                    ? [...examPrepInputs.questionTypes, type]
                                    : examPrepInputs.questionTypes.filter(t => t !== type);
                                  setExamPrepInputs({...examPrepInputs, questionTypes: newTypes});
                                }}
                                className="w-4 h-4 text-purple-600 rounded border-slate-600 bg-slate-800 focus:ring-purple-500 focus:ring-offset-slate-900"
                              />
                              <span className="text-sm text-slate-300">{type}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </>
                  )}

                  {activeTool === ToolType.EXTENDED_LEARNING_PLAN && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Learning Goal / Subject</label>
                        <input 
                          type="text" 
                          required
                          value={extendedPlanInputs.goal}
                          onChange={e => setExtendedPlanInputs({...extendedPlanInputs, goal: e.target.value})}
                          placeholder="e.g. Master Python Programming"
                          className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all placeholder-slate-500"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-slate-400 mb-1">Total Duration</label>
                          <input 
                            type="text"
                            required 
                            value={extendedPlanInputs.duration}
                            onChange={e => setExtendedPlanInputs({...extendedPlanInputs, duration: e.target.value})}
                            placeholder="e.g. 3 months"
                            className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all placeholder-slate-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-slate-400 mb-1">Time Commitment</label>
                          <input 
                            type="text"
                            required 
                            value={extendedPlanInputs.weeklyCommitment}
                            onChange={e => setExtendedPlanInputs({...extendedPlanInputs, weeklyCommitment: e.target.value})}
                            placeholder="e.g. 5 hours/week"
                            className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all placeholder-slate-500"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Current Skill Level</label>
                        <select 
                          value={extendedPlanInputs.currentLevel}
                          onChange={e => setExtendedPlanInputs({...extendedPlanInputs, currentLevel: e.target.value})}
                          className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all"
                        >
                          <option value="Beginner">Beginner</option>
                          <option value="Intermediate">Intermediate</option>
                          <option value="Advanced">Advanced</option>
                        </select>
                      </div>
                    </>
                  )}

                  {activeTool === ToolType.CONCEPT_EXPLAINER && (
                    <>
                       <div>
                        <label className="block text-sm font-medium text-slate-400 mb-1">Concept to Explain</label>
                        <input 
                          type="text" 
                          required
                          value={conceptInputs.topic}
                          onChange={e => setConceptInputs({...conceptInputs, topic: e.target.value})}
                          placeholder="e.g. Quantum Entanglement"
                          className="w-full px-4 py-2 bg-white text-slate-900 rounded-lg border border-slate-700 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 outline-none transition-all placeholder-slate-500"
                        />
                      </div>
                      <div className="p-4 bg-amber-900/20 rounded-lg text-sm text-amber-200 border border-amber-900/50 flex gap-2">
                        <Lightbulb className="w-5 h-5 flex-shrink-0" />
                        <p>This tool breaks down complex ideas into simple analogies, ELI5 explanations, and common misconceptions.</p>
                      </div>
                    </>
                  )}

                  <button 
                    type="submit"
                    disabled={generatorState.isLoading}
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-xl shadow-lg shadow-purple-900/50 transition-all transform active:scale-95 disabled:opacity-70 disabled:cursor-not-allowed flex justify-center items-center gap-2 mt-4"
                  >
                    {generatorState.isLoading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        Generating...
                      </>
                    ) : (
                      <>
                        <Wand2 className="w-5 h-5" />
                        Generate Content
                        {usageCount < MAX_FREE_USAGE && (
                           <span className="ml-1 text-purple-200 text-xs font-normal">({MAX_FREE_USAGE - usageCount} left)</span>
                        )}
                      </>
                    )}
                  </button>
                </form>
              </div>
            </div>

            {/* Results Column */}
            <div className="xl:col-span-8 flex flex-col h-[600px] xl:h-auto min-h-[500px]">
               {generatorState.error && (
                <div className="bg-red-900/20 border border-red-900/50 text-red-300 px-4 py-3 rounded-xl flex items-center gap-2 mb-4 animate-fade-in">
                  <AlertCircle className="w-5 h-5" />
                  <p>{generatorState.error}</p>
                </div>
              )}

              {!generatorState.result && !generatorState.isLoading && !generatorState.error && (
                <div className="flex-1 flex flex-col items-center justify-center text-slate-500 bg-slate-900/30 rounded-xl border-2 border-dashed border-slate-800 p-8">
                  <div className="w-16 h-16 bg-slate-900 rounded-full flex items-center justify-center mb-4 border border-slate-800">
                    <Wand2 className="w-8 h-8 text-slate-700" />
                  </div>
                  <h3 className="text-lg font-medium text-slate-400 mb-2">Ready to Create</h3>
                  <p className="text-center max-w-sm">Select a tool from the sidebar and fill out the form to generate custom educational content.</p>
                </div>
              )}

              {generatorState.isLoading && (
                 <div className="flex-1 flex flex-col items-center justify-center bg-slate-900 rounded-xl border border-slate-800 shadow-sm p-8">
                   <div className="relative w-20 h-20 mb-6">
                     <div className="absolute top-0 left-0 w-full h-full border-4 border-slate-800 rounded-full"></div>
                     <div className="absolute top-0 left-0 w-full h-full border-4 border-purple-500 rounded-full border-t-transparent animate-spin"></div>
                     <Wand2 className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-purple-500 w-8 h-8" />
                   </div>
                   <h3 className="text-xl font-semibold text-slate-200 animate-pulse">Designing Curriculum...</h3>
                   <p className="text-slate-500 mt-2">Crafting personalized content just for you.</p>
                 </div>
              )}

              {generatorState.result && !generatorState.isLoading && (
                <ResultDisplay 
                  content={generatorState.result.text} 
                  imageUrl={generatorState.result.imageUrl}
                  onSave={handleSaveToHistory}
                  isSaved={!!currentHistoryId}
                />
              )}
            </div>
          </div>
        </div>
      </main>

      <HistorySidebar 
        history={history}
        onSelect={handleHistorySelect}
        onDelete={deleteHistoryItem}
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
      />
    </div>
  );
};

export default App;
