import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Copy, Check, Save, Image as ImageIcon } from 'lucide-react';

interface ResultDisplayProps {
  content: string;
  imageUrl?: string;
  onSave?: () => void;
  isSaved?: boolean;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ content, imageUrl, onSave, isSaved }) => {
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-900 rounded-xl shadow-lg border border-slate-800 overflow-hidden flex flex-col h-full animate-fade-in">
      <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/30">
        <h3 className="font-semibold text-slate-200">Generated Output</h3>
        <div className="flex gap-2">
          {onSave && (
            <button
              onClick={onSave}
              disabled={isSaved}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium rounded-md transition-colors
                ${isSaved 
                  ? 'text-green-400 bg-green-900/20 cursor-default' 
                  : 'text-slate-400 hover:text-purple-400 hover:bg-slate-800 border border-transparent hover:border-slate-700'
                }`}
            >
              {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              {isSaved ? 'Saved' : 'Save'}
            </button>
          )}
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-slate-400 hover:text-purple-400 hover:bg-slate-800 rounded-md transition-colors border border-transparent hover:border-slate-700"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      </div>
      <div className="p-8 overflow-y-auto bg-slate-900 prose prose-invert prose-slate max-w-none scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-slate-900">
        
        {imageUrl && (
          <div className="mb-8 rounded-lg overflow-hidden border border-slate-800 shadow-md">
            <img 
              src={imageUrl} 
              alt="Generated visual aid" 
              className="w-full h-auto object-cover max-h-96"
            />
            <div className="bg-slate-950 p-2 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
              <ImageIcon className="w-3 h-3" />
              AI Generated Visual Aid
            </div>
          </div>
        )}

        <ReactMarkdown
          components={{
            h1: ({node, ...props}) => <h1 className="text-3xl font-bold text-slate-100 mb-6 pb-2 border-b border-slate-800" {...props} />,
            h2: ({node, ...props}) => <h2 className="text-2xl font-semibold text-slate-200 mt-8 mb-4" {...props} />,
            h3: ({node, ...props}) => <h3 className="text-xl font-medium text-slate-200 mt-6 mb-3" {...props} />,
            ul: ({node, ...props}) => <ul className="list-disc list-outside ml-6 space-y-1 my-4 text-slate-300" {...props} />,
            ol: ({node, ...props}) => <ol className="list-decimal list-outside ml-6 space-y-1 my-4 text-slate-300" {...props} />,
            li: ({node, ...props}) => <li className="text-slate-300 pl-1" {...props} />,
            p: ({node, ...props}) => <p className="text-slate-300 leading-relaxed mb-4" {...props} />,
            blockquote: ({node, ...props}) => <blockquote className="border-l-4 border-purple-500 pl-4 py-1 my-4 bg-purple-900/10 italic text-slate-400 rounded-r" {...props} />,
            code: ({node, ...props}) => <code className="bg-slate-800 text-purple-300 px-1.5 py-0.5 rounded text-sm font-mono" {...props} />,
            pre: ({node, ...props}) => <pre className="bg-slate-50 text-slate-900 border border-slate-200 p-4 rounded-lg overflow-x-auto my-4 text-sm font-mono shadow-inner" {...props} />
          }}
        >
          {content}
        </ReactMarkdown>
      </div>
    </div>
  );
};

export default ResultDisplay;