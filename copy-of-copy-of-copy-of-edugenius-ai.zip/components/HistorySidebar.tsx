
import React from 'react';
import { HistoryItem, ToolType } from '../types';
import { Clock, BookOpen, GraduationCap, FileQuestion, Lightbulb, Trash2, X, Image as ImageIcon, Calendar } from 'lucide-react';

interface HistorySidebarProps {
  history: HistoryItem[];
  onSelect: (item: HistoryItem) => void;
  onDelete: (id: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const getIcon = (tool: ToolType) => {
  switch (tool) {
    case ToolType.LESSON_PLAN: return <BookOpen className="w-4 h-4" />;
    case ToolType.STUDY_GUIDE: return <GraduationCap className="w-4 h-4" />;
    case ToolType.EXAM_PREP: return <FileQuestion className="w-4 h-4" />;
    case ToolType.CONCEPT_EXPLAINER: return <Lightbulb className="w-4 h-4" />;
    case ToolType.EXTENDED_LEARNING_PLAN: return <Calendar className="w-4 h-4" />;
    default: return <Clock className="w-4 h-4" />;
  }
};

const HistorySidebar: React.FC<HistorySidebarProps> = ({ history, onSelect, onDelete, isOpen, onClose }) => {
  return (
    <div className={`fixed inset-y-0 right-0 z-50 w-80 bg-slate-950 border-l border-slate-800 shadow-2xl transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
      <div className="flex items-center justify-between p-4 border-b border-slate-800">
        <h2 className="text-lg font-semibold text-slate-100 flex items-center gap-2">
          <Clock className="w-5 h-5 text-purple-500" />
          History
        </h2>
        <button onClick={onClose} className="p-1 hover:bg-slate-800 rounded-full transition-colors">
          <X className="w-5 h-5 text-slate-400" />
        </button>
      </div>
      
      <div className="overflow-y-auto h-[calc(100vh-64px)] p-4 space-y-3">
        {history.length === 0 ? (
          <div className="text-center text-slate-500 py-10">
            <p>No generated items yet.</p>
          </div>
        ) : (
          history.map((item) => (
            <div 
              key={item.id} 
              className="group flex flex-col p-3 rounded-lg border border-slate-800 hover:border-purple-500/50 hover:shadow-sm hover:shadow-purple-900/10 bg-slate-900 cursor-pointer transition-all"
              onClick={() => onSelect(item)}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1
                  ${item.tool === ToolType.LESSON_PLAN ? 'bg-blue-900/30 text-blue-300' : 
                    item.tool === ToolType.STUDY_GUIDE ? 'bg-green-900/30 text-green-300' :
                    item.tool === ToolType.EXAM_PREP ? 'bg-purple-900/30 text-purple-300' :
                    item.tool === ToolType.EXTENDED_LEARNING_PLAN ? 'bg-pink-900/30 text-pink-300' :
                    'bg-amber-900/30 text-amber-300'
                  }`}>
                  {getIcon(item.tool)}
                  {item.tool.replace(/_/g, ' ')}
                </span>
                <button 
                  onClick={(e) => { e.stopPropagation(); onDelete(item.id); }}
                  className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-red-400 transition-opacity"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <h3 className="text-sm font-semibold text-slate-200 line-clamp-2 mb-1">
                {item.title}
              </h3>
              <div className="flex items-center justify-between mt-1">
                <span className="text-xs text-slate-500">
                  {new Date(item.timestamp).toLocaleDateString()}
                </span>
                {item.imageUrl && (
                  <ImageIcon className="w-3 h-3 text-slate-600" aria-label="Contains image" />
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default HistorySidebar;
