import React from 'react';
import { Lock, Star, CheckCircle, X } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 rounded-2xl shadow-2xl border border-slate-800 w-full max-w-md overflow-hidden transform transition-all scale-100">
        <div className="bg-gradient-to-r from-purple-700 to-indigo-700 p-6 text-white text-center relative">
          <button onClick={onClose} className="absolute top-4 right-4 text-white/70 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
          <div className="w-16 h-16 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-md border border-white/20">
            <Lock className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold mb-1">Free Limit Reached</h2>
          <p className="text-purple-100">You've used all 5 free generations.</p>
        </div>
        
        <div className="p-8">
          <div className="space-y-4 mb-8">
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
              <p className="text-slate-300">Unlimited lesson plans & study guides</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
              <p className="text-slate-300">Advanced AI models (GPT-4 class)</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
              <p className="text-slate-300">Export to PDF & Word</p>
            </div>
          </div>

          <button className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-4 px-6 rounded-xl shadow-lg shadow-purple-900/50 transition-all transform active:scale-95 flex items-center justify-center gap-2 mb-4">
            <Star className="w-5 h-5 fill-current" />
            Upgrade to Pro - $9.99/mo
          </button>
          
          <button 
            onClick={onClose}
            className="w-full text-slate-500 hover:text-slate-300 font-medium text-sm transition-colors"
          >
            Maybe later
          </button>
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;