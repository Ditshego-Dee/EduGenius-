
export enum ToolType {
  LESSON_PLAN = 'LESSON_PLAN',
  STUDY_GUIDE = 'STUDY_GUIDE',
  EXAM_PREP = 'EXAM_PREP',
  CONCEPT_EXPLAINER = 'CONCEPT_EXPLAINER',
  EXTENDED_LEARNING_PLAN = 'EXTENDED_LEARNING_PLAN'
}

export interface GenerationResult {
  text: string;
  imageUrl?: string;
}

export interface GeneratorState {
  isLoading: boolean;
  result: GenerationResult | null;
  error: string | null;
}

export interface LessonPlanInputs {
  topic: string;
  gradeLevel: string;
  duration: string;
  teachingStyle: string;
}

export interface StudyGuideInputs {
  topic: string;
  level: string;
}

export interface ExamPrepInputs {
  topic: string;
  difficulty: string;
  questionTypes: string[]; // e.g., ['multiple choice', 'short answer']
}

export interface ConceptExplainerInputs {
  topic: string;
}

export interface ExtendedLearningPlanInputs {
  goal: string;
  duration: string;
  currentLevel: string;
  weeklyCommitment: string;
}

export interface HistoryItem {
  id: string;
  tool: ToolType;
  title: string; // The topic usually
  content: string;
  imageUrl?: string;
  timestamp: number;
}
